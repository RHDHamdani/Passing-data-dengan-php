<?php

    $nama = $_POST['nama'];
    $hp = $_POST['hp'];

    echo "<h2><center> hai ".$nama."</center><h2>";

    echo "<center>Nomor hp anda adalah ".$hp;
?>
